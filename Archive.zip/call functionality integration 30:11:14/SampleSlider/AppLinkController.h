//
//  AppLinkController.h
//  SampleSlider
//
//  Created by Jayesh on 27/11/14.
//  Copyright (c) 2014 WhiteSnow. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppLinkController : UIViewController <UITableViewDelegate,UITableViewDataSource>

@end
